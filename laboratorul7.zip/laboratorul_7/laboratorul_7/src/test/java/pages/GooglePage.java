package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class GooglePage {
    WebDriver driver;

    public GooglePage(WebDriver driver) {
        this.driver = driver;
    }

    public By searchBar = By.name("q");
    public By results = By.cssSelector("#search h3");
    public By didYouMean = By.xpath(
            "//*[contains(text(),'Did you mean') or " +
                    "contains(text(),'Ai dorit să scrii') or " +
                    "contains(text(),'Ai vrut să spui')]"
    );

    public void open() {
        driver.get("https://www.google.com/");
    }

    public void search(String text) {
        driver.findElement(searchBar).sendKeys(text);
        driver.findElement(searchBar).submit();
    }

    public void emptySearch() {
        driver.findElement(searchBar).submit();
    }
}
