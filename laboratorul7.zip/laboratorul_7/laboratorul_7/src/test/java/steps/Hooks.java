package steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.File;
import java.nio.file.Files;

public class Hooks {

    public static WebDriver driver;
    private long startTime;

    @Before
    public void start(Scenario scenario) {
        startTime = System.currentTimeMillis();
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.addArguments("--disable-infobars");
        options.addArguments("--start-maximized");

        driver = new org.openqa.selenium.chrome.ChromeDriver(options);

        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @After
    public void stop(Scenario scenario) {

        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;
        long seconds = duration / 1000;

        scenario.log("Durata scenariului: " + seconds + " secunde (" + duration + " ms)");

        if (scenario.isFailed()) {
            try {
                File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
                byte[] bytes = Files.readAllBytes(screenshot.toPath());
                scenario.attach(bytes, "image/png", "screenshot");
            } catch (Exception ignored) {}
        }

        driver.quit();
    }
}
