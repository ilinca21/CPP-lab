package steps;

import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.GooglePage;

import java.time.Duration;

import static org.junit.Assert.*;

public class GoogleSteps {

    WebDriver driver = Hooks.driver;
    GooglePage googlePage = new GooglePage(driver);
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

    @Given("utilizatorul deschide pagina Google")
    public void deschide_google() {
        googlePage.open();
    }

    @Then("pagina trebuie sa contina titlul {string}")
    public void verifica_titlu(String text) {
        assertTrue(driver.getTitle().contains(text));
    }

    @When("utilizatorul cauta {string}")
    public void cauta(String text) {
        googlePage.search(text);
    }

    @Then("ar trebui sa apara cel putin {int} rezultate")
    public void verifica_rezultate(int min) {
        new WebDriverWait(driver, Duration.ofSeconds(5))
                .until(d -> d.findElements(googlePage.results).size() > 0);

        int count = driver.findElements(googlePage.results).size();
        assertTrue(count >= min);
    }

    @When("utilizatorul apasa cautare fara text")
    public void cauta_fara_text() {
        googlePage.emptySearch();
    }

    @Then("nu trebuie sa se intample nimic")
    public void nimic() {
        assertEquals("Google", driver.getTitle());
    }

    @Then("trebuie sa apara mesajul Ai dorit să scrii:")
    public void verifica_did_you_mean() {
        GooglePage google = new GooglePage(driver);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        boolean displayed = false;
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(google.didYouMean));
            displayed = true;
        } catch (Exception ignored) {}

        assertTrue("Mesajul 'Ai dorit să scrii / Did you mean' NU a fost găsit!", displayed);
    }
}
