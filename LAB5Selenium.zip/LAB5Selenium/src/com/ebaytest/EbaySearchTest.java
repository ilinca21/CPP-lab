package com.ebaytest;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class EbaySearchTest {

    public static void main(String[] args) {
        System.out.println("Starting eBay Test...");

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Ilinca\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");

        // Configurare Chrome
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");

        WebDriver driver = new ChromeDriver(options);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        try {
            System.out.println("Step 1: Opening ebay.com");
            driver.get("https://www.ebay.com");

            System.out.println("Step 2: Searching for 'computer'");
            WebElement searchBox = wait.until(
                    ExpectedConditions.elementToBeClickable(By.id("gh-ac"))
            );
            searchBox.sendKeys("computer" + Keys.RETURN);

            System.out.println("Step 3: Verifying header");
            WebElement header = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(By.id("gh-logo"))
            );

            if (header.isDisplayed()) {
                System.out.println("SUCCESS: Header is displayed!");
            } else {
                System.out.println("FAIL: Header not found");
            }

            Thread.sleep(3000);

        } catch (Exception e) {
            System.out.println("Test failed: " + e.getMessage());
            e.printStackTrace();
        } finally {
            driver.quit();
            System.out.println("Test completed");
        }
    }
}