package utils;

import org.openqa.selenium.By;

public class Locators {
    // PRODUCT ELEMENTS
    public static final By PRODUCT_CARDS = By.cssSelector(".col-md-3.product-men");
    public static final By PRODUCT_NAMES = By.cssSelector(".col-md-3.product-men h4 a");
    public static final By PRODUCT_PRICES = By.cssSelector(".col-md-3.product-men .item_price");

    // CART ELEMENTS
    public static final By ADD_TO_CART_BUTTONS = By.cssSelector(".col-md-3.product-men input[type='submit'][value='Add to cart']");

    // SORT & FILTER
    public static final By SORT_DROPDOWN = By.id("country1");
    public static final By PRICE_FILTER_INPUTS = By.cssSelector("input[type='number']");
    public static final By FILTER_BUTTON = By.cssSelector("button[type='submit']");
}