package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.DriverManager;
import static org.junit.Assert.assertEquals;

public class QuickViewSteps {

    private WebDriver driver;
    private WebDriverWait wait;

    // Locatorii
    public static final By PRODUCTS = By.cssSelector(".col-md-3.product-men");
    public static final By QUICK_VIEW_BUTTON = By.cssSelector(".link-product-add-cart");


    public QuickViewSteps() {
        this.driver = DriverManager.getDriver();
        this.wait = new WebDriverWait(driver, 10);
    }

    @Given("I am on the products page")
    public void i_am_on_the_products_page() {
        driver.get("https://loving-hermann-e2094b.netlify.app/mens");
    }

    @When("I click quick view on product {int}")
    public void i_click_quick_view_on_product(int productIndex) {
        // așteptăm produsele
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(PRODUCTS));

        // preluăm produsul dorit
        WebElement product = driver.findElements(PRODUCTS).get(productIndex - 1);

        // facem hover ca să apară Quick View
        new Actions(driver).moveToElement(product).perform();

        // click pe Quick View
        WebElement button = product.findElement(QUICK_VIEW_BUTTON);
        button.click();

        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("h3")));
        } catch (Exception e) {
            System.out.println("The product title was not found after clicking Quick View");
        }
    }

    @Then("the product in the quick view modal should be product {int}")
    public void the_product_in_the_quick_view_modal_should_be_product(int productIndex) {
        String actualName;
        try {
            actualName = driver.findElement(By.tagName("h3")).getText();
        } catch (Exception e) {
            actualName = "No titles found";
        }

        // lista produselor așteptate
        String expectedName;
        switch(productIndex) {
            case 1: expectedName = "Formal Blue Shirt"; break;
            case 2: expectedName = "Big Wing Sneakers  (Navy)"; break;
            default: expectedName = "Unknown Product"; break;
        }

        if (!expectedName.equals(actualName)) {
            System.out.println("The displayed product is NOT the expected one! Expected: "
                    + expectedName);
        } else {
            System.out.println("The displayed product is correct: " + actualName);
        }

        assertEquals("The displayed product is wrong!", expectedName, actualName);
    }
}
