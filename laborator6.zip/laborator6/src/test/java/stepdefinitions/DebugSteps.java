package stepdefinitions;

import io.cucumber.java.en.Given;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utils.DriverManager;

import java.util.List;

public class DebugSteps {

    private WebDriver driver = DriverManager.getDriver();

    @Given("I perform complete site analysis")
    public void i_perform_complete_site_analysis() {
        System.out.println(" COMPLETE SITE ANALYSIS STARTED");
        System.out.println("==================================");

        analyzePageStructure();
        analyzeRealProducts();
        analyzeNavigation();
        analyzeProductDetails();
        analyzeCartFlow();
        analyzeQuickViewFlow();
        analyzeSearchAndFilters();

        System.out.println("==================================");
        System.out.println(" COMPLETE SITE ANALYSIS FINISHED");
    }

    @Given("I find exact product structure")
    public void i_find_exact_product_structure() {
        System.out.println("=== FINDING EXACT PRODUCT STRUCTURE ===");

        // Caută TOATE elementele care conțin prețuri și analizează părinții lor
        List<WebElement> allPrices = driver.findElements(By.cssSelector(".info-product-price, .item_price"));
        System.out.println("Total price elements found: " + allPrices.size());

        for (int i = 0; i < Math.min(allPrices.size(), 5); i++) {
            WebElement price = allPrices.get(i);
            System.out.println("\n--- Price Element " + i + " ---");
            System.out.println("Text: " + price.getText());
            System.out.println("Class: " + price.getAttribute("class"));

            // Analizează ierarhia părinților
            try {
                WebElement parent = price.findElement(By.xpath("./.."));
                System.out.println("Parent class: " + parent.getAttribute("class"));

                WebElement grandParent = parent.findElement(By.xpath("./.."));
                System.out.println("Grandparent class: " + grandParent.getAttribute("class"));

                WebElement greatGrandParent = grandParent.findElement(By.xpath("./.."));
                System.out.println("Great-grandparent class: " + greatGrandParent.getAttribute("class"));

                // Verifică dacă este un container de produs
                if (greatGrandParent.getAttribute("class").contains("col-md-3")) {
                    System.out.println(" FOUND PRODUCT CONTAINER: " + greatGrandParent.getAttribute("class"));
                    System.out.println("Full HTML structure:");
                    System.out.println(greatGrandParent.getAttribute("outerHTML"));
                }
            } catch (Exception e) {
                System.out.println(" Error analyzing hierarchy: " + e.getMessage());
            }
        }
    }

    @Given("I analyze product containers difference")
    public void i_analyze_product_containers_difference() {
        System.out.println("=== ANALYZING PRODUCT CONTAINERS DIFFERENCE ===");

        List<WebElement> allContainers = driver.findElements(By.cssSelector(".col-md-3.product-men"));
        System.out.println("Total .col-md-3.product-men containers: " + allContainers.size());

        int productsWithNames = 0;
        int productsWithPrices = 0;
        int realProducts = 0;

        for (int i = 0; i < allContainers.size(); i++) {
            WebElement container = allContainers.get(i);
            List<WebElement> names = container.findElements(By.cssSelector("h4 a"));
            List<WebElement> prices = container.findElements(By.cssSelector(".item_price"));
            List<WebElement> addToCartButtons = container.findElements(By.cssSelector("input[type='submit'][value='Add to cart']"));

            boolean hasName = !names.isEmpty();
            boolean hasPrice = !prices.isEmpty();
            boolean hasAddButton = !addToCartButtons.isEmpty();

            if (hasName && hasPrice && hasAddButton) {
                realProducts++;
                System.out.println(" Product " + i + ": " + names.get(0).getText() + " - " + prices.get(0).getText());
            } else {
                System.out.println(" Container " + i + ": No name=" + hasName + ", No price=" + hasPrice + ", No button=" + hasAddButton);
            }

            if (hasName) productsWithNames++;
            if (hasPrice) productsWithPrices++;
        }

        System.out.println("\n SUMMARY:");
        System.out.println("Total containers: " + allContainers.size());
        System.out.println("Containers with names: " + productsWithNames);
        System.out.println("Containers with prices: " + productsWithPrices);
        System.out.println("REAL PRODUCTS: " + realProducts);
    }

    private void analyzePageStructure() {
        System.out.println("\n PAGE STRUCTURE ANALYSIS");
        System.out.println("URL: " + driver.getCurrentUrl());
        System.out.println("Title: " + driver.getTitle());

        // Analizează structura principală a paginii
        analyzeSection("Header sections", "header, .header, .navbar");
        analyzeSection("Main content", "main, .main, .container, .content");
        analyzeSection("Footer sections", "footer, .footer");
    }

    private void analyzeRealProducts() {
        System.out.println("\n REAL PRODUCTS ANALYSIS");

        // Caută TOATE elementele care ar putea fi produse
        String[] potentialProductContainers = {
                ".agile_top_brand_left",
                ".product", ".item", ".card",
                ".col-md-3", ".col-md-4", ".col-sm-6",
                ".snipcart-thumb", ".product-grid",
                ".product-item", ".item-grid",
                "[class*='product']", "[class*='item']"
        };

        for (String selector : potentialProductContainers) {
            List<WebElement> elements = driver.findElements(By.cssSelector(selector));
            if (!elements.isEmpty()) {
                System.out.println(" " + selector + " → " + elements.size() + " elements");

                // Analizează primul element din fiecare selector
                WebElement firstElement = elements.get(0);
                System.out.println("   Classes: " + firstElement.getAttribute("class"));
                System.out.println("   Visible: " + firstElement.isDisplayed());

                // Verifică dacă conține elemente de produs
                List<WebElement> names = firstElement.findElements(By.cssSelector("h1, h2, h3, h4, h5, h6"));
                List<WebElement> prices = firstElement.findElements(By.cssSelector(".price, .cost, .item_price"));
                List<WebElement> images = firstElement.findElements(By.cssSelector("img"));
                List<WebElement> buttons = firstElement.findElements(By.cssSelector("button, .btn, .w3view-cart"));

                System.out.println("   Contains - Names: " + names.size() +
                        ", Prices: " + prices.size() +
                        ", Images: " + images.size() +
                        ", Buttons: " + buttons.size());

                if (names.size() > 0 && prices.size() > 0) {
                    System.out.println("   LIKELY PRODUCT CONTAINER!");
                    System.out.println("   Name: " + names.get(0).getText());
                    System.out.println("   Price: " + prices.get(0).getText());
                }
            }
        }
    }

    private void analyzeNavigation() {
        System.out.println("\nNAVIGATION ANALYSIS");

        analyzeSection("Menu items", ".menu, .nav, .navbar-nav, [class*='menu']");
        analyzeSection("Dropdowns", ".dropdown, .dropdown-toggle");
        analyzeSection("Sort options", "[class*='sort'], select");
        analyzeSection("Filter options", "[class*='filter'], .filters, aside");
    }

    private void analyzeProductDetails() {
        System.out.println("\nPRODUCT DETAILS ANALYSIS");

        // Găsește TOATE prețurile și numele de pe pagină
        List<WebElement> allPrices = driver.findElements(By.cssSelector(".info-product-price, .item_price, .price, [class*='price']"));
        List<WebElement> allNames = driver.findElements(By.cssSelector(".product-name, .name, h3, h4, [class*='name']"));

        System.out.println("All prices found: " + allPrices.size());
        for (int i = 0; i < Math.min(allPrices.size(), 5); i++) {
            WebElement price = allPrices.get(i);
            System.out.println("   " + i + ": " + price.getText() +
                    " | Parent: " + getParentInfo(price));
        }

        System.out.println("All names found: " + allNames.size());
        for (int i = 0; i < Math.min(allNames.size(), 5); i++) {
            WebElement name = allNames.get(i);
            System.out.println("   " + i + ": " + name.getText() +
                    " | Parent: " + getParentInfo(name));
        }
    }

    private void analyzeCartFlow() {
        System.out.println("\nCART FLOW ANALYSIS");

        // Analizează icon-ul coșului
        List<WebElement> cartIcons = driver.findElements(By.cssSelector(".wthreecartaits, .cart, .basket, [class*='cart']"));
        System.out.println("Cart icons: " + cartIcons.size());
        for (WebElement icon : cartIcons) {
            System.out.println("   Class: " + icon.getAttribute("class"));
            System.out.println("   Visible: " + icon.isDisplayed());
            System.out.println("   Clickable: " + icon.isEnabled());
        }

        // Caută butoane Add to Cart
        analyzeSection("Add to Cart buttons", ".add-to-cart, .my-cart, [class*='cart'], .btn-primary, .btn-success");
    }

    private void analyzeQuickViewFlow() {
        System.out.println("\nQUICK VIEW FLOW ANALYSIS");

        // Butoane Quick View
        List<WebElement> quickViewButtons = driver.findElements(By.cssSelector(".w3view-cart, [class*='view'], [class*='quick']"));
        System.out.println("Quick View buttons: " + quickViewButtons.size());
        for (WebElement button : quickViewButtons) {
            System.out.println("   Class: " + button.getAttribute("class"));
            System.out.println("   Visible: " + button.isDisplayed());
            System.out.println("   Clickable: " + button.isEnabled());
            System.out.println("   Text: '" + button.getText() + "'");
            System.out.println("   Parent: " + getParentInfo(button));
        }

        // Modale
        List<WebElement> modals = driver.findElements(By.cssSelector(".modal, .modal-content, [role='dialog']"));
        System.out.println("Modal elements: " + modals.size());
        for (WebElement modal : modals) {
            System.out.println("   Class: " + modal.getAttribute("class"));
            System.out.println("   Visible: " + modal.isDisplayed());
        }
    }

    private void analyzeSearchAndFilters() {
        System.out.println("\nSEARCH & FILTERS ANALYSIS");

        // Search
        List<WebElement> searchInputs = driver.findElements(By.cssSelector("input[type='search'], input[name='search']"));
        System.out.println("Search inputs: " + searchInputs.size());

        // Filtre
        analyzeSection("Price filters", "input[type='number'], input[type='range'], [class*='price']");
        analyzeSection("Category filters", "[class*='category'], [class*='type']");
        analyzeSection("Filter buttons", ".btn-filter, [class*='filter']");
    }

    // ===== HELPER METHODS =====

    private void analyzeSection(String sectionName, String cssSelector) {
        try {
            List<WebElement> elements = driver.findElements(By.cssSelector(cssSelector));
            System.out.println(sectionName + ": " + elements.size() + " elements");

            if (!elements.isEmpty()) {
                for (int i = 0; i < Math.min(elements.size(), 2); i++) {
                    WebElement element = elements.get(i);
                    String text = element.getText().replace("\n", " ").trim();
                    if (text.length() > 30) text = text.substring(0, 30) + "...";

                    System.out.println("   " + i + ": '" + text + "' | Class: " + element.getAttribute("class"));
                }
            }
        } catch (Exception e) {
            System.out.println(sectionName + ": Error - " + e.getMessage());
        }
    }

    private String getParentInfo(WebElement element) {
        try {
            WebElement parent = element.findElement(By.xpath(".."));
            return "Class: '" + parent.getAttribute("class") + "' | Tag: " + parent.getTagName();
        } catch (Exception e) {
            return "Parent not available";
        }
    }
}