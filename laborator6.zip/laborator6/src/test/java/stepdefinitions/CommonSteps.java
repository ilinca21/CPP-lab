package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utils.DriverManager;
import utils.Locators;

import java.util.List;

public class CommonSteps {
    private WebDriver driver = DriverManager.getDriver();

    @Given("I am on the homepage")
    public void i_am_on_the_homepage() {
        driver.get("https://loving-hermann-e2094b.netlify.app/");
    }
    @Given("I am on the mens products page")
    public void i_am_on_the_mens_products_page() {
        driver.get("https://loving-hermann-e2094b.netlify.app/mens");
    }
    @Then("I should see products displayed")
    public void i_should_see_products_displayed() {
        List<WebElement> products = driver.findElements(Locators.PRODUCT_CARDS);
        System.out.println("Found " + products.size() + " products");
        Assert.assertTrue("Should see products displayed", products.size() > 0);
    }
}