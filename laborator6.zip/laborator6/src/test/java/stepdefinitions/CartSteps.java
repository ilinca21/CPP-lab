package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import utils.DriverManager;
import utils.Locators;

import java.util.List;

public class CartSteps {

    private WebDriver driver = DriverManager.getDriver();

    @When("I add product {int} to cart")
    public void i_add_product_to_cart(int productNumber) {
        try {
            List<WebElement> addToCartButtons = driver.findElements(Locators.ADD_TO_CART_BUTTONS);
            List<WebElement> productPrices = driver.findElements(Locators.PRODUCT_PRICES);
            List<WebElement> productNames = driver.findElements(Locators.PRODUCT_NAMES);

            if (addToCartButtons.size() >= productNumber) {
                String productName = productNames.get(productNumber - 1).getText();
                String productPrice = productPrices.get(productNumber - 1).getText();

                System.out.println("Adding to cart: " + productName + " - " + productPrice);

                WebElement addButton = addToCartButtons.get(productNumber - 1);
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].click();", addButton);

                Thread.sleep(2000);
                System.out.println("Product added to cart");
            }
        } catch (Exception e) {
            System.out.println("Error adding to cart: " + e.getMessage());
        }
    }

    @Then("the product should be successfully added to cart")
    public void the_product_should_be_successfully_added_to_cart() {
        // Verifica daca produsul a fost adaugat
        System.out.println("Product addition process completed");
    }
}