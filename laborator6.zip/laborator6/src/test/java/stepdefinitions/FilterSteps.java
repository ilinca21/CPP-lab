package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import utils.DriverManager;
import utils.Locators;

import java.util.ArrayList;
import java.util.List;

public class FilterSteps {

    private WebDriver driver = DriverManager.getDriver();

    @When("I filter products by price range from {int} to {int}")
    public void i_filter_products_by_price_range_from_to(int minPrice, int maxPrice) {
        try {
            System.out.println("Looking for price filter inputs...");

            // Verifică dacă există input-uri pentru filtrare preț
            List<WebElement> priceInputs = driver.findElements(Locators.PRICE_FILTER_INPUTS);

            if (priceInputs.size() >= 2) {
                WebElement minInput = priceInputs.get(0);
                WebElement maxInput = priceInputs.get(1);

                // Curăță și completează valorile
                minInput.clear();
                maxInput.clear();
                minInput.sendKeys(String.valueOf(minPrice));
                maxInput.sendKeys(String.valueOf(maxPrice));

                System.out.println("Set price filter: $" + minPrice + " - $" + maxPrice);

                // Aplică filtrele
                applyPriceFilter();
                Thread.sleep(2000);
            } else {
                System.out.println("Price range verification");
                verifyPriceRangeManually(minPrice, maxPrice);
            }

        } catch (Exception e) {
            System.out.println("Error applying price filter: " + e.getMessage());
        }
    }

    @Then("all displayed products should have price between {int} and {int}")
    public void all_displayed_products_should_have_price_between_and(int minPrice, int maxPrice) {
        List<WebElement> productPrices = driver.findElements(Locators.PRODUCT_PRICES);
        System.out.println("Checking price range for " + productPrices.size() + " products");

        int productsInRange = 0;
        List<String> outOfRangeProducts = new ArrayList<>();

        int productsToCheck = Math.min(productPrices.size(), 8);

        for (int i = 0; i < productsToCheck; i++) {
            WebElement priceElement = productPrices.get(i);
            String priceText = priceElement.getText().replaceAll("[^0-9.]", "");

            if (!priceText.isEmpty()) {
                double price = Double.parseDouble(priceText);
                if (price >= minPrice && price <= maxPrice) {
                    productsInRange++;
                } else {
                    String productName = driver.findElements(Locators.PRODUCT_NAMES).get(i).getText();
                    outOfRangeProducts.add(productName + " - $" + price);
                }
            }
        }

        System.out.println(" Products in range $" + minPrice + "-$" + maxPrice + ": "
                + productsInRange + "/" + productsToCheck);


        if (!outOfRangeProducts.isEmpty()) {
            System.out.println("Products outside range: " + outOfRangeProducts);
            Assert.fail("Some products are outside the price range: " + outOfRangeProducts);
        } else {
            System.out.println("All checked products are in the specified price range");
        }
    }

    private void applyPriceFilter() {
        try {
            // Caută buton de aplicare filtru
            List<WebElement> filterButtons = driver.findElements(Locators.FILTER_BUTTON);
            if (!filterButtons.isEmpty()) {
                filterButtons.get(0).click();
                System.out.println("Applied price filter");
            }
        } catch (Exception e) {
            System.out.println("ℹNo filter button found");
        }
    }

    private void verifyPriceRangeManually(int minPrice, int maxPrice) {
        System.out.println("Verifying products in price range $" + minPrice + "-$" + maxPrice);

    }
}